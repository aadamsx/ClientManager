'use strict';
app.controller("companyCreateController", function($scope) {
    // controller's constructor:

});

