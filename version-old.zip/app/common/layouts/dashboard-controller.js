/**
 * Created by Aaron on 1/31/14.
 */
app.controller("dashboardController", function($scope) {
    // controller's constructor:

});


