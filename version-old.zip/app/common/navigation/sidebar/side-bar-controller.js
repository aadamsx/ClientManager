app.controller('sideBarController', function ($scope) {

});