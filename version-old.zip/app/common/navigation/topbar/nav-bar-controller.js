﻿app.controller('navbarController', function ($scope) {

});