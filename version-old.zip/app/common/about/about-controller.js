/**
 * Created by Aaron on 2/1/14.
 */
app.controller('aboutController', function ($scope) {

});
