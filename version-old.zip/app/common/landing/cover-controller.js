/**
 * Created by Aaron on 2/1/14.
 */
app.controller('coverController', function ($scope) {
    $scope.hideTopNavBar = true;
});
